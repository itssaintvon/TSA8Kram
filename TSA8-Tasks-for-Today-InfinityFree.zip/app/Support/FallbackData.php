<?php

namespace App\Support;

final class FallbackData
{
    public static function customers(): array
    {
        return [
            ['id' => 1, 'full_name' => 'Alicia Reyes', 'email' => 'alicia.reyes@example.com', 'phone' => '0917-555-1001'],
            ['id' => 2, 'full_name' => 'Brandon Cruz', 'email' => 'brandon.cruz@example.com', 'phone' => '0917-555-1002'],
            ['id' => 3, 'full_name' => 'Camille Santos', 'email' => 'camille.santos@example.com', 'phone' => '0917-555-1003'],
            ['id' => 4, 'full_name' => 'Daniel Flores', 'email' => 'daniel.flores@example.com', 'phone' => '0917-555-1004'],
            ['id' => 5, 'full_name' => 'Elena Navarro', 'email' => 'elena.navarro@example.com', 'phone' => '0917-555-1005'],
        ];
    }

    public static function users(): array
    {
        return [
            ['id' => 1, 'username' => 'mark.garcia', 'full_name' => 'Mark Garcia'],
            ['id' => 2, 'username' => 'sarah.lim', 'full_name' => 'Sarah Lim'],
            ['id' => 3, 'username' => 'jonas.villanueva', 'full_name' => 'Jonas Villanueva'],
            ['id' => 4, 'username' => 'nicole.tan', 'full_name' => 'Nicole Tan'],
            ['id' => 5, 'username' => 'paolo.mendoza', 'full_name' => 'Paolo Mendoza'],
        ];
    }
}
