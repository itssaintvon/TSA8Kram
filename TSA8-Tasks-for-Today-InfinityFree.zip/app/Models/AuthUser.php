<?php
namespace App\Models;
use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Auth\Authenticatable as AuthenticatableTrait;
use Illuminate\Database\Eloquent\Model;
class AuthUser extends Model implements Authenticatable
{
    use AuthenticatableTrait;
    protected $table = 'users';
    protected $fillable = ['username', 'full_name', 'password'];
    protected $hidden = ['password'];
}
