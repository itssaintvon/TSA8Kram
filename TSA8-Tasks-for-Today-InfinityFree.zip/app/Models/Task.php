<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Task extends Model
{
    protected $fillable = ['title', 'description', 'due_date', 'status', 'is_archived', 'completed_at'];
    protected $casts = ['is_archived' => 'boolean', 'due_date' => 'date', 'completed_at' => 'datetime'];
}
