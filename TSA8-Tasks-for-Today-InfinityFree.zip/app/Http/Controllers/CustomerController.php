<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Support\FallbackData;
use Illuminate\Http\Request;

class CustomerController extends Controller
{
    public function index()
    {
        $customers = class_exists('Illuminate\Database\Eloquent\Model')
            ? Customer::all()
            : FallbackData::customers();
        $data = ['page' => 'customers', 'title' => 'Customer Accounts', 'subtitle' => 'Manage customer records retrieved through Eloquent.', 'records' => $customers];
        return function_exists('view') ? view('accounts.customers', $data) : $data;
    }

    public function create()
    {
        return view('accounts.customers-create', [
            'page' => 'customers',
            'title' => 'Create Customer',
            'subtitle' => 'Add a customer account to the POS workspace.',
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'full_name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255'],
            'phone' => ['nullable', 'string', 'max:50'],
        ]);

        Customer::create(array_merge($validated, ['phone' => $validated['phone'] ?? '']));

        return redirect()->route('customers.index')->with('success', 'Customer created successfully.');
    }

    public function edit(Customer $customer)
    {
        return view('accounts.customers-edit', [
            'page' => 'customers',
            'title' => 'Edit Customer',
            'subtitle' => 'Update the selected customer account.',
            'customer' => $customer,
        ]);
    }

    public function update(Request $request, Customer $customer)
    {
        $validated = $request->validate([
            'full_name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255'],
            'phone' => ['nullable', 'string', 'max:50'],
        ]);

        $customer->update(array_merge($validated, ['phone' => $validated['phone'] ?? '']));

        return redirect()->route('customers.index')->with('success', 'Customer updated successfully.');
    }
}
