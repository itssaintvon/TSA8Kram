<?php
namespace App\Http\Controllers;
use App\Models\AuthUser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
class AuthController extends Controller
{
    public function showLogin() { return view('auth.login', ['page' => 'login', 'title' => 'Sign in', 'subtitle' => 'Sign in to manage tasks.']); }
    public function login(Request $request) { $credentials = $request->validate(['username' => ['required', 'string'], 'password' => ['required', 'string']]); $user = AuthUser::where('username', $credentials['username'])->first(); if (!$user || !Hash::check($credentials['password'], (string) $user->password)) return back()->withErrors(['username' => 'The provided credentials are incorrect.'])->withInput(); auth()->login($user); $request->session()->regenerate(); return redirect()->intended(route('tasks.index')); }
    public function logout(Request $request) { auth()->logout(); $request->session()->invalidate(); $request->session()->regenerateToken(); return redirect()->route('home'); }
}
