<?php
namespace App\Http\Controllers;
use App\Mail\TaskCompleted;
use App\Models\Task;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
class TaskController extends Controller
{
    public function index() { return view('tasks.index', ['page' => 'tasks', 'title' => 'Tasks for Today', 'subtitle' => 'Plan, complete, and archive your work.', 'tasks' => Task::where('is_archived', false)->latest()->get()]); }
    public function create() { return view('tasks.create', ['page' => 'tasks', 'title' => 'Create Task', 'subtitle' => 'Add a task to your work list.']); }
    public function store(Request $request) { $validated = $request->validate(['title' => ['required', 'string', 'max:255'], 'description' => ['nullable', 'string', 'max:5000'], 'due_date' => ['nullable', 'date'], 'status' => ['required', 'in:pending,in_progress,done']]); $validated['completed_at'] = $validated['status'] === 'done' ? now() : null; Task::create($validated); return redirect()->route('tasks.index')->with('success', 'Task created successfully.'); }
    public function edit(Task $task) { abort_if($task->is_archived, 404); return view('tasks.edit', ['page' => 'tasks', 'title' => 'Edit Task', 'subtitle' => 'Update the selected task.', 'task' => $task]); }
    public function update(Request $request, Task $task) { abort_if($task->is_archived, 404); $validated = $request->validate(['title' => ['required', 'string', 'max:255'], 'description' => ['nullable', 'string', 'max:5000'], 'due_date' => ['nullable', 'date'], 'status' => ['required', 'in:pending,in_progress,done']]); $wasDone = $task->status === 'done'; $isDone = $validated['status'] === 'done'; $validated['completed_at'] = $isDone ? ($task->completed_at ?? now()) : null; $task->update($validated); if (!$wasDone && $isDone) Mail::to(config('mail.task_recipient', env('TASK_NOTIFICATION_EMAIL', config('mail.from.address'))))->send(new TaskCompleted($task->fresh())); return redirect()->route('tasks.index')->with('success', 'Task updated successfully.'); }
    public function destroy(Task $task) { $task->update(['is_archived' => true]); return redirect()->route('tasks.index')->with('success', 'Task archived successfully.'); }
}
