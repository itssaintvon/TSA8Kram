<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Support\FallbackData;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Intervention\Image\Laravel\Facades\Image;

class UserController extends Controller
{
    public function index()
    {
        $users = class_exists('Illuminate\Database\Eloquent\Model')
            ? User::all()
            : FallbackData::users();
        $data = ['page' => 'users', 'title' => 'User Accounts', 'subtitle' => 'Review user records retrieved through Eloquent.', 'records' => $users];
        return function_exists('view') ? view('accounts.users', $data) : $data;
    }

    public function create()
    {
        return view('accounts.users-create', [
            'page' => 'users',
            'title' => 'Create User',
            'subtitle' => 'Add a user account to the POS workspace.',
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'username' => ['required', 'string', 'max:255', 'unique:users,username'],
            'full_name' => ['required', 'string', 'max:255'],
        ]);

        User::create($validated);

        return redirect()->route('users.index')->with('success', 'User created successfully.');
    }

    public function edit(User $user)
    {
        return view('accounts.users-edit', [
            'page' => 'users',
            'title' => 'Edit User',
            'subtitle' => 'Update account details and optionally upload a profile picture.',
            'user' => $user,
        ]);
    }

    public function update(Request $request, User $user)
    {
        $validated = $request->validate([
            'username' => ['required', 'string', 'max:255', Rule::unique('users', 'username')->ignore($user->id)],
            'full_name' => ['required', 'string', 'max:255'],
            'avatar' => ['nullable', 'image', 'max:2048'],
        ]);

        if ($request->hasFile('avatar')) {
            $filename = 'avatars/' . Str::uuid() . '.jpg';
            $preparedImage = Image::read($request->file('avatar'))
                ->cover(256, 256)
                ->toJpeg(85);

            Storage::disk('public')->put($filename, (string) $preparedImage);
            $validated['avatar'] = $filename;
        }

        $user->update($validated);

        return redirect()->route('users.index')->with('success', 'User updated successfully.');
    }

    public function avatar(User $user)
    {
        if ($user->avatar && Storage::disk('public')->exists($user->avatar)) {
            return redirect(Storage::disk('public')->url($user->avatar));
        }

        return redirect(URL::to('/images/avatar-placeholder.svg'));
    }
}
