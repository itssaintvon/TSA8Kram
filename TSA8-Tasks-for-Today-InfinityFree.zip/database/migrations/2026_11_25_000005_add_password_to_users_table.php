<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration
{
    public function up(): void { if (!Schema::hasColumn('users', 'password')) Schema::table('users', function (Blueprint $table): void { $table->string('password')->nullable()->after('username'); }); }
    public function down(): void { if (Schema::hasColumn('users', 'password')) Schema::table('users', fn (Blueprint $table) => $table->dropColumn('password')); }
};
