<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Customer;
use App\Models\User;
use App\Models\Task;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        Customer::query()->delete();
        User::query()->delete();

        Customer::create(['full_name' => 'Alicia Reyes', 'email' => 'alicia.reyes@example.com', 'phone' => '0917-555-1001']);
        Customer::create(['full_name' => 'Brandon Cruz', 'email' => 'brandon.cruz@example.com', 'phone' => '0917-555-1002']);
        Customer::create(['full_name' => 'Camille Santos', 'email' => 'camille.santos@example.com', 'phone' => '0917-555-1003']);
        Customer::create(['full_name' => 'Daniel Flores', 'email' => 'daniel.flores@example.com', 'phone' => '0917-555-1004']);
        Customer::create(['full_name' => 'Elena Navarro', 'email' => 'elena.navarro@example.com', 'phone' => '0917-555-1005']);

        User::create(['username' => 'mark.garcia', 'full_name' => 'Mark Garcia']);
        User::create(['username' => 'sarah.lim', 'full_name' => 'Sarah Lim']);
        User::create(['username' => 'jonas.villanueva', 'full_name' => 'Jonas Villanueva']);
        User::create(['username' => 'nicole.tan', 'full_name' => 'Nicole Tan']);
        User::create(['username' => 'paolo.mendoza', 'full_name' => 'Paolo Mendoza']);

        User::query()->update(['password' => Hash::make('password')]);
        Task::query()->delete();
        Task::create(['title' => 'Review project requirements', 'description' => 'Check the TSA8 instructions before submission.', 'due_date' => now()->toDateString(), 'status' => 'pending']);
        Task::create(['title' => 'Prepare activity screenshots', 'description' => 'Capture the create, update, archive, and email-log flow.', 'due_date' => now()->addDay()->toDateString(), 'status' => 'in_progress']);
    }
}
