@csrf
<label for="title">Task title</label><input id="title" name="title" value="{{ old('title', $task->title ?? '') }}" required>
<label for="description">Description</label><textarea id="description" name="description" rows="5">{{ old('description', $task->description ?? '') }}</textarea>
<label for="due_date">Due date</label><input id="due_date" name="due_date" type="date" value="{{ old('due_date', isset($task) && $task->due_date ? $task->due_date->format('Y-m-d') : '') }}">
<label for="status">Status</label><select id="status" name="status" required><option value="pending" @selected(old('status', $task->status ?? 'pending') === 'pending')>Pending</option><option value="in_progress" @selected(old('status', $task->status ?? '') === 'in_progress')>In progress</option><option value="done" @selected(old('status', $task->status ?? '') === 'done')>Done</option></select>
<div class="form-actions"><button class="button" type="submit">Save task</button><a class="button alt" href="{{ route('tasks.index') }}">Cancel</a></div>
