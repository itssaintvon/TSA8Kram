@extends('layouts.app')
@section('content')
<div class="section-head"><div><div class="eyebrow">Accounts / customers</div><h1>{{ $title }}</h1><p>{{ $subtitle }}</p></div><div class="actions"><a class="button" href="{{ route('customers.create') }}">+ Create customer</a><a class="button alt" href="{{ route('users.index') }}">View users</a></div></div>
@if (session('success'))<div class="feedback success">{{ session('success') }}</div>@endif
<div class="table-wrap"><table><thead><tr><th>ID</th><th>Full Name</th><th>Email</th><th>Phone</th><th>Actions</th></tr></thead><tbody>@foreach ($records as $record)<tr><td>{{ $record->id }}</td><td><strong>{{ $record->full_name }}</strong></td><td class="muted">{{ $record->email }}</td><td class="muted">{{ $record->phone }}</td><td><a class="table-link" href="{{ route('customers.edit', $record) }}">Edit</a></td></tr>@endforeach</tbody></table></div>
<p class="empty-note">Showing {{ $records->count() }} customer records retrieved through Eloquent.</p>
@endsection
