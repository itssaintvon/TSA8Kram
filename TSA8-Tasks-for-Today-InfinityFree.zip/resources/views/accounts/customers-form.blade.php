<label for="full_name">Full name</label>
<input id="full_name" name="full_name" type="text" value="{{ old('full_name', $customer->full_name ?? '') }}">
@error('full_name')<p class="field-error">{{ $message }}</p>@enderror
<label for="email">Email address</label>
<input id="email" name="email" type="email" value="{{ old('email', $customer->email ?? '') }}">
@error('email')<p class="field-error">{{ $message }}</p>@enderror
<label for="phone">Phone number</label>
<input id="phone" name="phone" type="text" value="{{ old('phone', $customer->phone ?? '') }}">
@error('phone')<p class="field-error">{{ $message }}</p>@enderror
<div class="form-actions"><button class="button" type="submit">Save customer</button><a class="button alt" href="{{ route('customers.index') }}">Cancel</a></div>
