<label for="username">Username</label>
<input id="username" name="username" type="text" value="{{ old('username', $user->username ?? '') }}">
@error('username')<p class="field-error">{{ $message }}</p>@enderror
<label for="full_name">Full name</label>
<input id="full_name" name="full_name" type="text" value="{{ old('full_name', $user->full_name ?? '') }}">
@error('full_name')<p class="field-error">{{ $message }}</p>@enderror
@if (isset($user))
<label for="avatar">Profile picture</label>
<input id="avatar" name="avatar" type="file" accept="image/*">
<p class="form-help">Optional. Image files only, maximum 2 MB. The image is cropped to a 256px square for display.</p>
@error('avatar')<p class="field-error">{{ $message }}</p>@enderror
@endif
<div class="form-actions"><button class="button" type="submit">Save user</button><a class="button alt" href="{{ route('users.index') }}">Cancel</a></div>
