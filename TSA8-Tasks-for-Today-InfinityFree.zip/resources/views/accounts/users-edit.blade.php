@extends('layouts.app')
@section('content')
<div class="section-head"><div><div class="eyebrow">Accounts / users</div><h1>{{ $title }}</h1><p>{{ $subtitle }}</p></div></div>
@include('accounts._form-errors')
<form class="account-form" action="{{ route('users.update', $user) }}" method="POST" enctype="multipart/form-data">
@csrf @method('PUT')
@include('accounts.users-form')
</form>
@endsection
