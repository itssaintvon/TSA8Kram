@extends('layouts.app')
@section('content')
<div class="section-head"><div><div class="eyebrow">Accounts / users</div><h1>{{ $title }}</h1><p>{{ $subtitle }}</p></div><div class="actions"><a class="button" href="{{ route('users.create') }}">+ Create user</a><a class="button alt" href="{{ route('customers.index') }}">View customers</a></div></div>
@if (session('success'))<div class="feedback success">{{ session('success') }}</div>@endif
<div class="table-wrap"><table><thead><tr><th>Avatar</th><th>ID</th><th>Username</th><th>Full Name</th><th>Actions</th></tr></thead><tbody>@foreach ($records as $record)<tr><td><img class="avatar-image" src="{{ $record->avatar ? Storage::disk('public')->url($record->avatar) : asset('images/avatar-placeholder.svg') }}" alt="Avatar for {{ $record->full_name }}"></td><td>{{ $record->id }}</td><td><strong>{{ $record->username }}</strong></td><td class="muted">{{ $record->full_name }}</td><td><a class="table-link" href="{{ route('users.edit', $record) }}">Edit</a></td></tr>@endforeach</tbody></table></div>
<p class="empty-note">Showing {{ $records->count() }} user records retrieved through Eloquent.</p>
@endsection
