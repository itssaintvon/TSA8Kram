@extends('layouts.app')
@section('content')
<div class="section-head"><div><div class="eyebrow">Accounts / customers</div><h1>{{ $title }}</h1><p>{{ $subtitle }}</p></div></div>
@include('accounts._form-errors')
<form class="account-form" action="{{ route('customers.store') }}" method="POST">
@csrf
@include('accounts.customers-form')
</form>
@endsection
