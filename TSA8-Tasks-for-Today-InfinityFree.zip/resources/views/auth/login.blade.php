@extends('layouts.app')
@section('content')
<div class="section-head"><div><div class="eyebrow">Protected workspace</div><h1>{{ $title }}</h1><p>{{ $subtitle }}</p></div></div>
@if($errors->any())<div class="feedback error">{{ $errors->first() }}</div>@endif
<form class="account-form" method="POST" action="{{ route('login.store') }}">@csrf
<label for="username">Username</label><input id="username" name="username" value="{{ old('username') }}" required autofocus>
<label for="password">Password</label><input id="password" name="password" type="password" required>
<div class="form-actions"><button class="button" type="submit">Sign in</button><a class="button alt" href="{{ route('home') }}">Cancel</a></div>
</form>
<p class="form-help">Demo accounts use the seeded password: <strong>password</strong>.</p>
@endsection
