@extends('layouts.app')
@section('content')
<div class="section-head"><div><div class="eyebrow">Account</div><h1>{{ $title }}</h1><p>{{ $subtitle }}</p></div></div>
<div class="info-grid"><article class="info-card"><h3>Tasks for Today user</h3><p>This profile page remains publicly viewable as required by TSA4. Management actions are protected by authentication.</p><p><strong>Demo username:</strong> mark.garcia</p></article></div>
@endsection
