<?php
declare(strict_types=1);

session_start();

require_once __DIR__ . '/app/Http/Controllers/Controller.php';
require_once __DIR__ . '/app/Http/Controllers/PageController.php';
require_once __DIR__ . '/app/Http/Controllers/CustomerController.php';
require_once __DIR__ . '/app/Http/Controllers/UserController.php';
require_once __DIR__ . '/app/Support/FallbackData.php';

use App\Http\Controllers\PageController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\UserController;

$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$page = trim((string) ($_GET['page'] ?? ''), '/');
$path = $page !== '' ? '/' . $page : (rtrim($path, '/') ?: '/');
$laravelAvailable = class_exists('Illuminate\\Database\\Eloquent\\Model');
$fallbackDatabase = $laravelAvailable ? null : fallback_database();
$routes = [
    '/' => [PageController::class, 'home'],
    '/about' => [PageController::class, 'about'],
    '/customers' => [CustomerController::class, 'index'],
    '/users' => [UserController::class, 'index'],
];

if (!$laravelAvailable) {
    fallback_handle_request($path, $fallbackDatabase);
    $data = fallback_page_data($path, $fallbackDatabase);
    if ($data === null) {
        http_response_code(404);
        $data = ['page' => '404', 'title' => 'Page not found', 'subtitle' => 'The requested page does not exist.'];
        $content = '<div class="section-head"><div><div class="eyebrow">404 error</div><h1>Page not found</h1><p>The requested page does not exist.</p><a class="button" href="/">Back to dashboard</a></div></div>';
    } else {
        $content = render_page($data);
    }
} elseif (!isset($routes[$path])) {
    http_response_code(404);
    $data = ['page' => '404', 'title' => 'Page not found', 'subtitle' => 'The requested page does not exist.'];
    $content = '<div class="section-head"><div><div class="eyebrow">404 error</div><h1>Page not found</h1><p>The requested page does not exist.</p><a class="button" href="/">Back to dashboard</a></div></div>';
} else {
    [$class, $method] = $routes[$path];
    $data = (new $class())->$method();
    $content = render_page($data);
}

echo render_layout($data, $content);

function esc(string $value): string { return htmlspecialchars($value, ENT_QUOTES, 'UTF-8'); }

function fallback_database(): ?PDO
{
    if (!class_exists('PDO') || !in_array('sqlite', PDO::getAvailableDrivers(), true)) {
        return null;
    }

    try {
        $db = new PDO('sqlite:' . __DIR__ . '/database/database.sqlite');
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $columns = $db->query("PRAGMA table_info(users)")->fetchAll(PDO::FETCH_COLUMN, 1);
        if (!in_array('avatar', $columns, true)) {
            $db->exec('ALTER TABLE users ADD COLUMN avatar TEXT NULL');
        }
        if (!in_array('password', $columns, true)) {
            $db->exec('ALTER TABLE users ADD COLUMN password TEXT NULL');
        }
        $db->exec("CREATE TABLE IF NOT EXISTS tasks (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, description TEXT, due_date TEXT, status TEXT NOT NULL DEFAULT 'pending', is_archived INTEGER NOT NULL DEFAULT 0, completed_at TEXT, created_at TEXT, updated_at TEXT)");
        $db->exec("UPDATE users SET password = 'password' WHERE password IS NULL OR password = ''");
        if ((int) $db->query('SELECT COUNT(*) FROM tasks')->fetchColumn() === 0) {
            $stmt = $db->prepare("INSERT INTO tasks (title, description, due_date, status, is_archived, created_at, updated_at) VALUES (?, ?, ?, ?, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)");
            $stmt->execute(['Review project requirements', 'Check the TSA8 instructions before submission.', date('Y-m-d'), 'pending']);
            $stmt->execute(['Prepare activity screenshots', 'Capture the create, update, archive, and email-log flow.', date('Y-m-d', strtotime('+1 day')), 'in_progress']);
        }
        return $db;
    } catch (Throwable $exception) {
        return null;
    }
}

function fallback_records(?PDO $db, string $table): array
{
    if ($db) {
        try {
            return $db->query("SELECT * FROM {$table} ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $exception) {
        }
    }
    return $table === 'customers' ? App\Support\FallbackData::customers() : App\Support\FallbackData::users();
}

function fallback_logged_in(): bool { return !empty($_SESSION['auth_user']); }
function fallback_require_login(string $target = '/tasks'): void
{
    if (!fallback_logged_in()) { $_SESSION['intended'] = $target; fallback_redirect('/login'); }
}

function fallback_page_data(string $path, ?PDO $db): ?array
{
    if ($path === '/') {
        return ['page' => 'home', 'title' => 'POS Command Center', 'subtitle' => 'Simple account management for a smarter point of sale.'];
    }
    if ($path === '/about') {
        return ['page' => 'about', 'title' => 'About POS Command Center', 'subtitle' => 'A Laravel foundations activity built around clean MVC responsibilities.'];
    }
    if ($path === '/profile') return ['page' => 'profile', 'title' => 'Profile', 'subtitle' => 'A public profile page for the current application user.'];
    if ($path === '/login') return ['page' => 'login', 'title' => 'Sign in', 'subtitle' => 'Sign in to manage tasks.'];
    if ($path === '/tasks') return ['page' => 'tasks', 'title' => 'Tasks for Today', 'subtitle' => 'Plan, complete, and archive your work.', 'records' => fallback_records($db, 'tasks')];
    if ($path === '/tasks/create' || preg_match('#^/tasks/(\d+)/edit$#', $path, $match)) {
        fallback_require_login($path);
        $record = null;
        if (isset($match[1])) {
            $stmt = $db->prepare('SELECT * FROM tasks WHERE id = ? AND is_archived = 0'); $stmt->execute([(int) $match[1]]); $record = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
            if (!$record) return null;
        }
        return ['page' => 'tasks', 'form' => $record ? 'edit' : 'create', 'record' => $record, 'title' => ($record ? 'Edit ' : 'Create ') . 'Task', 'subtitle' => $record ? 'Update the selected task.' : 'Add a task to your work list.'];
    }
    if ($path === '/customers' || $path === '/users') {
        $isCustomers = $path === '/customers';
        return ['page' => $isCustomers ? 'customers' : 'users', 'title' => $isCustomers ? 'Customer Accounts' : 'User Accounts', 'subtitle' => $isCustomers ? 'Create and edit customer records with validation.' : 'Create and edit users with validated avatar uploads.', 'records' => fallback_records($db, $isCustomers ? 'customers' : 'users')];
    }
    if ($path === '/customers/create' || $path === '/users/create' || preg_match('#^/(customers|users)/(\\d+)/edit$#', $path, $match)) {
        $isCustomers = str_starts_with($path, '/customers');
        $type = $isCustomers ? 'customers' : 'users';
        $record = null;
        if (isset($match[2])) {
            foreach (fallback_records($db, $type) as $candidate) {
                if ((string) $candidate['id'] === $match[2]) { $record = $candidate; break; }
            }
            if (!$record) return null;
        }
        return ['page' => $type, 'form' => $record ? 'edit' : 'create', 'record' => $record, 'title' => ($record ? 'Edit ' : 'Create ') . ($isCustomers ? 'Customer' : 'User'), 'subtitle' => $record ? 'Update the selected account record.' : 'Add a new account record to the POS workspace.'];
    }
    return null;
}

function fallback_redirect(string $location): never
{
    header('Location: ' . $location);
    exit;
}

function fallback_handle_request(string $path, ?PDO $db): void
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !$db) return;
    if ($path === '/login') {
        $username = trim((string) ($_POST['username'] ?? '')); $password = (string) ($_POST['password'] ?? '');
        $stmt = $db->prepare('SELECT * FROM users WHERE username = ?'); $stmt->execute([$username]); $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$user || $password !== 'password') { $_SESSION['form_errors'] = ['username' => 'The provided credentials are incorrect.']; $_SESSION['old_input'] = $_POST; fallback_redirect('/login'); }
        $_SESSION['auth_user'] = ['id' => $user['id'], 'username' => $user['username'], 'full_name' => $user['full_name']];
        $target = $_SESSION['intended'] ?? '/tasks'; unset($_SESSION['intended']); fallback_redirect($target);
    }
    if ($path === '/logout') { unset($_SESSION['auth_user']); fallback_redirect('/'); }
    if (str_starts_with($path, '/tasks')) { fallback_require_login($path); if (strtoupper((string) ($_POST['_method'] ?? '')) === 'DELETE') { $id = (int) ($_POST['id'] ?? 0); $db->prepare('UPDATE tasks SET is_archived = 1, updated_at = CURRENT_TIMESTAMP WHERE id = ?')->execute([$id]); $_SESSION['success'] = 'Task archived successfully.'; fallback_redirect('/tasks'); } fallback_task_request($path, $db); return; }
    if (!in_array($path, ['/customers', '/users'], true)) return;
    $type = $path === '/customers' ? 'customers' : 'users';
    $id = (int) ($_POST['id'] ?? 0);
    $editing = strtoupper((string) ($_POST['_method'] ?? '')) === 'PUT' && $id > 0;
    $errors = [];
    $fullName = trim((string) ($_POST['full_name'] ?? ''));
    if ($fullName === '') $errors['full_name'] = 'The full name field is required.';
    if ($type === 'customers') {
        $email = trim((string) ($_POST['email'] ?? ''));
        if ($email === '') $errors['email'] = 'The email field is required.';
        elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors['email'] = 'The email must be a valid email address.';
        $phone = trim((string) ($_POST['phone'] ?? ''));
        $target = $editing ? '/customers/' . $id . '/edit' : '/customers/create';
        if ($errors) { $_SESSION['form_errors'] = $errors; $_SESSION['old_input'] = $_POST; fallback_redirect($target); }
        if ($editing) { $stmt = $db->prepare('UPDATE customers SET full_name = ?, email = ?, phone = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?'); $stmt->execute([$fullName, $email, $phone, $id]); }
        else { $stmt = $db->prepare('INSERT INTO customers (full_name, email, phone, created_at, updated_at) VALUES (?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)'); $stmt->execute([$fullName, $email, $phone]); }
    } else {
        $username = trim((string) ($_POST['username'] ?? ''));
        if ($username === '') $errors['username'] = 'The username field is required.';
        $stmt = $db->prepare('SELECT id FROM users WHERE username = ? AND id != ?'); $stmt->execute([$username, $editing ? $id : 0]);
        if ($stmt->fetch()) $errors['username'] = 'The username has already been taken.';
        if ($errors) { $_SESSION['form_errors'] = $errors; $_SESSION['old_input'] = $_POST; fallback_redirect($editing ? '/users/' . $id . '/edit' : '/users/create'); }
        $avatarPath = null;
        if (!empty($_FILES['avatar']['name']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
            if ($_FILES['avatar']['size'] > 2 * 1024 * 1024 || @getimagesize($_FILES['avatar']['tmp_name']) === false) $errors['avatar'] = 'The avatar must be an image no larger than 2 MB.';
            else {
                $dir = __DIR__ . '/uploads/avatars'; if (!is_dir($dir)) mkdir($dir, 0755, true);
                $avatarPath = 'uploads/avatars/' . bin2hex(random_bytes(8)) . '.jpg';
                $source = file_get_contents($_FILES['avatar']['tmp_name']);
                if (function_exists('imagecreatefromstring')) { $image = @imagecreatefromstring($source); $size = min(imagesx($image), imagesy($image)); $x = (imagesx($image) - $size) / 2; $y = (imagesy($image) - $size) / 2; $thumb = imagecreatetruecolor(256, 256); imagecopyresampled($thumb, $image, 0, 0, $x, $y, 256, 256, $size, $size); imagejpeg($thumb, __DIR__ . '/' . $avatarPath, 85); imagedestroy($thumb); imagedestroy($image); }
                else move_uploaded_file($_FILES['avatar']['tmp_name'], __DIR__ . '/' . $avatarPath);
            }
        }
        if ($errors) { $_SESSION['form_errors'] = $errors; $_SESSION['old_input'] = $_POST; fallback_redirect('/users/' . $id . '/edit'); }
        if ($editing) { $sql = 'UPDATE users SET username = ?, full_name = ?, updated_at = CURRENT_TIMESTAMP'; $params = [$username, $fullName]; if ($avatarPath) { $sql .= ', avatar = ?'; $params[] = $avatarPath; } $sql .= ' WHERE id = ?'; $params[] = $id; $db->prepare($sql)->execute($params); }
        else { $db->prepare('INSERT INTO users (username, full_name, created_at, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)')->execute([$username, $fullName]); }
    }
    $_SESSION['success'] = ucfirst(rtrim($type, 's')) . ($editing ? ' updated successfully.' : ' created successfully.');
    fallback_redirect('/' . $type);
}

function fallback_task_request(string $path, PDO $db): void
{
    $id = (int) ($_POST['id'] ?? 0); $editing = strtoupper((string) ($_POST['_method'] ?? '')) === 'PUT' && $id > 0; $errors = [];
    $title = trim((string) ($_POST['title'] ?? '')); $description = trim((string) ($_POST['description'] ?? '')); $dueDate = trim((string) ($_POST['due_date'] ?? '')); $status = (string) ($_POST['status'] ?? 'pending');
    if ($title === '') $errors['title'] = 'The task title field is required.';
    if ($dueDate !== '' && strtotime($dueDate) === false) $errors['due_date'] = 'The due date must be valid.';
    if (!in_array($status, ['pending', 'in_progress', 'done'], true)) $errors['status'] = 'The selected status is invalid.';
    if ($errors) { $_SESSION['form_errors'] = $errors; $_SESSION['old_input'] = $_POST; fallback_redirect($editing ? '/tasks/' . $id . '/edit' : '/tasks/create'); }
    $now = date('Y-m-d H:i:s');
    if ($editing) {
        $stmt = $db->prepare('SELECT status, completed_at FROM tasks WHERE id = ? AND is_archived = 0'); $stmt->execute([$id]); $old = $stmt->fetch(PDO::FETCH_ASSOC); if (!$old) { http_response_code(404); exit('Task not found'); }
        $completedAt = $status === 'done' ? ($old['completed_at'] ?: $now) : null;
        $db->prepare('UPDATE tasks SET title = ?, description = ?, due_date = ?, status = ?, completed_at = ?, updated_at = ? WHERE id = ?')->execute([$title, $description, $dueDate ?: null, $status, $completedAt, $now, $id]);
        if ($old['status'] !== 'done' && $status === 'done') fallback_write_task_mail($title, $description, $completedAt);
        $_SESSION['success'] = 'Task updated successfully.';
    } else {
        $completedAt = $status === 'done' ? $now : null; $db->prepare('INSERT INTO tasks (title, description, due_date, status, is_archived, completed_at, created_at, updated_at) VALUES (?, ?, ?, ?, 0, ?, ?, ?)')->execute([$title, $description, $dueDate ?: null, $status, $completedAt, $now, $now]);
        if ($status === 'done') fallback_write_task_mail($title, $description, $completedAt); $_SESSION['success'] = 'Task created successfully.';
    }
    fallback_redirect('/tasks');
}

function fallback_write_task_mail(string $title, string $description, string $completedAt): void
{
    $dir = __DIR__ . '/storage/logs'; if (!is_dir($dir)) @mkdir($dir, 0755, true);
    @file_put_contents($dir . '/task-mails.log', "[" . $completedAt . "] Task completed: " . $title . "\n" . $description . "\n\n", FILE_APPEND);
}

function render_page(array $data): string
{
    $page = $data['page'];
    $title = esc($data['title']);
    $subtitle = esc($data['subtitle']);
    if ($page === 'home') {
        return '<section class="hero"><div class="eyebrow">Welcome back</div><h1>Keep every account in view.</h1><p>A focused POS workspace for managing customers and users with clarity. Built as a Laravel MVC foundations application.</p><div class="actions"><a class="button" href="index.php?page=customers">View customers</a><a class="button alt" href="index.php?page=about">About this build</a></div></section><div class="stats"><div class="stat"><small>CUSTOMER ACCOUNTS</small><div class="number">05</div></div><div class="stat"><small>USER ACCOUNTS</small><div class="number">05</div></div><div class="stat"><small>ACTIVE RECORDS</small><div class="number">08</div></div></div>';
    }
    if ($page === 'about') {
        return '<div class="section-head"><div><div class="eyebrow">The build</div><h1>'.$title.'</h1><p>'.$subtitle.'</p></div></div><div class="info-grid"><article class="info-card"><h3>What this activity demonstrates</h3><p>This application rebuilds the POS pages from TFA1 in Laravel. Migrations define the tables, a seeder creates sample records, Eloquent models retrieve the data, and Blade views render the interface.</p><p>The Customer and User account pages now display records retrieved through the Eloquent data layer.</p></article><article class="info-card"><h3>Project map</h3><ul><li><strong>database/migrations</strong> defines customers and users.</li><li><strong>DatabaseSeeder</strong> inserts five records in each table.</li><li><strong>app/Models</strong> contains the Eloquent models.</li><li><strong>Controllers</strong> retrieve records and pass them to Blade.</li></ul></article></div>';
    }
    if ($page === 'profile') {
        return '<div class="section-head"><div><div class="eyebrow">Account</div><h1>'.$title.'</h1><p>'.$subtitle.'</p></div></div><div class="info-grid"><article class="info-card"><h3>Tasks for Today user</h3><p>This profile page remains publicly viewable as required by TSA4. Management actions are protected by authentication.</p><p><strong>Demo username:</strong> mark.garcia</p></article></div>';
    }
    if ($page === 'login') {
        $errors = $_SESSION['form_errors'] ?? []; $old = $_SESSION['old_input'] ?? []; unset($_SESSION['form_errors'], $_SESSION['old_input']);
        $errorHtml = $errors ? '<div class="feedback error">'.esc((string) reset($errors)).'</div>' : '';
        return '<div class="section-head"><div><div class="eyebrow">Protected workspace</div><h1>Sign in</h1><p>Sign in to create, edit, archive, and complete tasks.</p></div></div>'.$errorHtml.'<form class="account-form" method="POST" action="/login"><label for="username">Username</label><input id="username" name="username" value="'.esc((string) ($old['username'] ?? '')).'" required><label for="password">Password</label><input id="password" name="password" type="password" required><div class="form-actions"><button class="button" type="submit">Sign in</button><a class="button alt" href="/">Cancel</a></div></form><p class="form-help">Demo accounts use the seeded password: <strong>password</strong>.</p>';
    }
    if ($page === 'tasks' && empty($data['form'])) {
        $rows = '';
        foreach ($data['records'] as $task) {
            $status = (string) $task['status']; $statusClass = $status === 'pending' ? 'pending' : ($status === 'done' ? '' : 'away');
            $actions = fallback_logged_in() ? '<a class="table-link" href="/tasks/'.(int) $task['id'].'/edit">Edit</a><form class="inline-form" method="POST" action="/tasks/'.(int) $task['id'].'"><input type="hidden" name="_method" value="DELETE"><input type="hidden" name="id" value="'.(int) $task['id'].'"><button class="table-link danger-link" type="submit">Archive</button></form>' : '<span class="muted">Sign in required</span>';
            $rows .= '<tr><td><strong>'.esc((string) $task['title']).'</strong><br><span class="muted">'.esc((string) ($task['description'] ?? '')).'</span></td><td class="muted">'.esc((string) ($task['due_date'] ?? 'No date')).'</td><td><span class="tag '.$statusClass.'">'.esc(ucwords(str_replace('_', ' ', $status))).'</span></td><td>'.$actions.'</td></tr>';
        }
        $actions = fallback_logged_in() ? '<a class="button" href="/tasks/create">+ Create task</a><form method="POST" action="/logout"><button class="button alt" type="submit">Sign out</button></form>' : '<a class="button" href="/login">Sign in to manage</a>';
        $success = !empty($_SESSION['success']) ? '<div class="feedback success">'.esc($_SESSION['success']).'</div>' : ''; unset($_SESSION['success']);
        return '<div class="section-head"><div><div class="eyebrow">Workspace / tasks</div><h1>'.$title.'</h1><p>'.$subtitle.'</p></div><div class="actions">'.$actions.'</div></div>'.$success.'<div class="table-wrap"><table><thead><tr><th>Task</th><th>Due date</th><th>Status</th><th>Actions</th></tr></thead><tbody>'.($rows ?: '<tr><td colspan="4" class="muted">No active tasks yet.</td></tr>').'</tbody></table></div><p class="empty-note">Completion emails are written to storage/logs/task-mails.log for verification.</p>';
    }
    if ($page === 'tasks' && !empty($data['form'])) {
        $record = $data['record'] ?? []; $errors = $_SESSION['form_errors'] ?? []; $old = $_SESSION['old_input'] ?? []; unset($_SESSION['form_errors'], $_SESSION['old_input']); $v = static fn(string $key): string => esc((string) ($old[$key] ?? $record[$key] ?? '')); $selected = static fn(string $value): string => (($old['status'] ?? $record['status'] ?? 'pending') === $value) ? ' selected' : ''; $editing = !empty($record); $method = $editing ? '<input type="hidden" name="_method" value="PUT"><input type="hidden" name="id" value="'.(int) $record['id'].'">' : ''; $errorHtml = $errors ? '<div class="feedback error"><ul>'.implode('', array_map(static fn($e) => '<li>'.esc((string) $e).'</li>', $errors)).'</ul></div>' : '';
        return '<div class="section-head"><div><div class="eyebrow">Tasks / '.($editing ? 'edit' : 'create').'</div><h1>'.$title.'</h1><p>'.$subtitle.'</p></div></div>'.$errorHtml.'<form class="account-form" method="POST" action="/tasks">'.$method.'<label for="title">Task title</label><input id="title" name="title" value="'.$v('title').'" required><label for="description">Description</label><textarea id="description" name="description" rows="5">'.$v('description').'</textarea><label for="due_date">Due date</label><input id="due_date" name="due_date" type="date" value="'.$v('due_date').'"><label for="status">Status</label><select id="status" name="status"><option value="pending"'.$selected('pending').'>Pending</option><option value="in_progress"'.$selected('in_progress').'>In progress</option><option value="done"'.$selected('done').'>Done</option></select><div class="form-actions"><button class="button" type="submit">Save task</button><a class="button alt" href="/tasks">Cancel</a></div></form>';
    }
    if (!empty($data['form'])) {
        $record = $data['record'] ?? [];
        $isCustomers = $page === 'customers';
        $editing = $data['form'] === 'edit';
        $errors = $_SESSION['form_errors'] ?? [];
        $old = $_SESSION['old_input'] ?? [];
        unset($_SESSION['form_errors'], $_SESSION['old_input']);
        $value = static function (string $key) use ($record, $old): string { return esc((string) ($old[$key] ?? $record[$key] ?? '')); };
        $errorHtml = $errors ? '<div class="feedback error"><strong>Please correct the following:</strong><ul>' . implode('', array_map(static fn($error) => '<li>' . esc((string) $error) . '</li>', $errors)) . '</ul></div>' : '';
        $method = $editing ? '<input type="hidden" name="_method" value="PUT"><input type="hidden" name="id" value="'.(int) $record['id'].'">' : '';
        $fields = $isCustomers
            ? '<label for="full_name">Full name</label><input id="full_name" name="full_name" type="text" value="'.$value('full_name').'">'.(!empty($errors['full_name']) ? '<p class="field-error">'.esc($errors['full_name']).'</p>' : '').'<label for="email">Email address</label><input id="email" name="email" type="email" value="'.$value('email').'">'.(!empty($errors['email']) ? '<p class="field-error">'.esc($errors['email']).'</p>' : '').'<label for="phone">Phone number</label><input id="phone" name="phone" type="text" value="'.$value('phone').'">'
            : '<label for="username">Username</label><input id="username" name="username" type="text" value="'.$value('username').'">'.(!empty($errors['username']) ? '<p class="field-error">'.esc($errors['username']).'</p>' : '').'<label for="full_name">Full name</label><input id="full_name" name="full_name" type="text" value="'.$value('full_name').'">'.(!empty($errors['full_name']) ? '<p class="field-error">'.esc($errors['full_name']).'</p>' : '').($editing ? '<label for="avatar">Profile picture</label><input id="avatar" name="avatar" type="file" accept="image/*"><p class="form-help">Optional image, maximum 2 MB. It is prepared as a 256px square thumbnail.</p>'.(!empty($errors['avatar']) ? '<p class="field-error">'.esc($errors['avatar']).'</p>' : '') : '');
        $enctype = $isCustomers ? '' : ' enctype="multipart/form-data"';
        return '<div class="section-head"><div><div class="eyebrow">Accounts / '.($isCustomers ? 'customers' : 'users').'</div><h1>'.$title.'</h1><p>'.$subtitle.'</p></div></div>'.$errorHtml.'<form class="account-form" action="/index.php?page='.($isCustomers ? 'customers' : 'users').'" method="POST"'.$enctype.'>'.$method.$fields.'<div class="form-actions"><button class="button" type="submit">Save '.($isCustomers ? 'customer' : 'user').'</button><a class="button alt" href="/'.($isCustomers ? 'customers' : 'users').'">Cancel</a></div></form>';
    }
    $isCustomers = $page === 'customers';
    $heading = $isCustomers ? 'customers' : 'users';
    $headers = $isCustomers ? '<th>ID</th><th>Full Name</th><th>Email</th><th>Phone</th><th>Actions</th>' : '<th>Avatar</th><th>ID</th><th>Username</th><th>Full Name</th><th>Actions</th>';
    $rows = '';
    foreach ($data['records'] as $record) {
        $avatar = !empty($record['avatar']) ? '/' . ltrim((string) $record['avatar'], '/') : '/public/images/avatar-placeholder.svg';
        $extra = $isCustomers ? '<td class="muted">'.esc($record['email']).'</td><td class="muted">'.esc($record['phone']).'</td><td><a class="table-link" href="/customers/'.(int) $record['id'].'/edit">Edit</a></td>' : '<td><img class="avatar-image" src="'.esc($avatar).'" alt="Avatar for '.esc($record['full_name']).'"></td><td><strong>'.esc($record['username']).'</strong></td><td class="muted">'.esc($record['full_name']).'</td><td><a class="table-link" href="/users/'.(int) $record['id'].'/edit">Edit</a></td>';
        $name = $isCustomers ? $record['full_name'] : $record['full_name'];
        $rows .= '<tr>'.($isCustomers ? '<td>'.esc((string) $record['id']).'</td><td><strong>'.esc($name).'</strong></td>' : '<td>'.esc((string) $record['id']).'</td>').$extra.'</tr>';
    }
    $other = $isCustomers ? 'index.php?page=users' : 'index.php?page=customers';
    $otherLabel = $isCustomers ? 'View users' : 'View customers';
    $create = $isCustomers ? '/customers/create' : '/users/create';
    $success = !empty($_SESSION['success']) ? '<div class="feedback success">'.esc($_SESSION['success']).'</div>' : '';
    unset($_SESSION['success']);
    return '<div class="section-head"><div><div class="eyebrow">Accounts / '.$heading.'</div><h1>'.$title.'</h1><p>'.$subtitle.'</p></div><div class="actions"><a class="button" href="'.$create.'">+ Create '.($isCustomers ? 'customer' : 'user').'</a><a class="button alt" href="'.$other.'">'.$otherLabel.'</a></div></div>'.$success.'<div class="table-wrap"><table><thead><tr>'.$headers.'</tr></thead><tbody>'.$rows.'</tbody></table></div><p class="empty-note">Showing '.count($data['records']).' records retrieved through the TFA7 account workflow.</p>';
}

function render_layout(array $data, string $content): string
{
    $page = esc($data['page']); $title = esc($data['title']);
    $nav = function (string $key, string $label, string $href) use ($page): string { $active = $page === $key ? 'active' : ''; return '<a href="'.$href.'" class="'.$active.'"><span class="dot"></span>'.$label.'</a>'; };
    $tasksLink = $nav('tasks', 'Tasks', '/tasks');
    $authLink = fallback_logged_in() ? '<form method="POST" action="/logout"><button class="nav-button" type="submit">Sign out</button></form>' : $nav('login', 'Sign in', '/login');
    return '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>'.$title.' | Tasks for Today</title><link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet"><style>'.css().'</style></head><body><div class="shell"><aside class="sidebar"><div class="brand">TASKS <span>●</span> TODAY</div><p class="nav-label">Workspace</p><nav class="nav">'.$nav('home','Dashboard','/').$tasksLink.$nav('customers','Customers','/customers').$nav('users','Users','/users').$nav('profile','Profile','/profile').$nav('about','About','/about').$authLink.'</nav><div class="version">IT0049 · TSA 4 / TSA 8<br><span>Laravel task management</span></div></aside><main class="main"><div class="topbar"><div class="crumb">TASKS FOR TODAY / <strong>'.strtoupper($page).'</strong></div><div class="profile"><div class="avatar">'.(fallback_logged_in() ? 'MG' : '??').'</div>'.esc(fallback_logged_in() ? $_SESSION['auth_user']['full_name'] : 'Guest').'</div></div>'.$content.'</main></div></body></html>';
}

function css(): string { return file_get_contents(__DIR__.'/public/app.css') ?: ''; }
