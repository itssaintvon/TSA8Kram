<?php
return [
    'default' => env('MAIL_MAILER', 'log'),
    'mailers' => ['log' => ['transport' => 'log'], 'smtp' => ['transport' => 'smtp', 'host' => env('MAIL_HOST', '127.0.0.1'), 'port' => env('MAIL_PORT', 2525), 'encryption' => env('MAIL_ENCRYPTION'), 'username' => env('MAIL_USERNAME'), 'password' => env('MAIL_PASSWORD'), 'timeout' => null, 'local_domain' => env('MAIL_EHLO_DOMAIN')]],
    'from' => ['address' => env('MAIL_FROM_ADDRESS', 'tasks@example.test'), 'name' => env('MAIL_FROM_NAME', 'Tasks for Today')],
    'task_recipient' => env('TASK_NOTIFICATION_EMAIL', 'student@example.test'),
];
