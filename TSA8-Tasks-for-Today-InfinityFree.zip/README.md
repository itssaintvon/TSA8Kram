# Tasks for Today Management System TSA8

This project recreates the TFA7 Laravel application and extends it for TSA4/TSA8: full task CRUD, authentication-protected management actions, soft archiving, and a completion email notification.

## Laravel setup

1. Install PHP 8.2 or later and Composer.
2. Copy .env.example to .env.
3. Run composer install.
4. Run php artisan key:generate.
5. Run `php artisan migrate --seed`.
6. Run `php artisan storage:link` to expose prepared avatars from the public disk.
7. Run `php artisan serve` and open http://127.0.0.1:8000.

The seeded demo users use the password `password`. The Welcome, Task List, Profile, and About pages can be viewed without signing in; creating, editing, and archiving tasks require authentication.

## Data layer requirements

- database/migrations creates the customers and users tables.
- DatabaseSeeder inserts five customer records and five user records.
- app/Models/Customer.php and app/Models/User.php are Eloquent models.
- CustomerController and UserController retrieve records with Eloquent.
- Blade views loop through model objects and display the required schema.

## TFA7 requirements implemented

- `/customers/create` validates `full_name` and `email`, then inserts a customer.
- `/users/create` validates required, unique usernames and full names, then inserts a user.
- `/customers/{customer}/edit` and `/users/{user}/edit` pre-fill existing data and update it with PUT requests.
- User edit accepts an optional image, validates it as an image up to 2 MB, crops it to a 256px square with Intervention Image, stores the prepared JPEG through `Storage::disk('public')`, and saves only the resulting path in `users.avatar`.
- The user list displays each prepared avatar and uses `public/images/avatar-placeholder.svg` when no avatar exists.
- All POST and PUT forms include CSRF protection, retain old input, and display validation errors.

The image package is installed with Composer through `intervention/image-laravel`. If dependencies have not been installed yet, run `composer install` before starting the application.

## TSA8 task requirements implemented

- `/tasks` lists non-archived tasks; `/tasks/create` creates a validated task.
- `/tasks/{task}/edit` updates title, description, due date, and status.
- Delete is implemented as soft deletion through `is_archived`, so archived records remain in the database.
- When a task changes from pending or in-progress to done, `TaskCompleted` is sent through Laravel's `Mail` facade. With `MAIL_MAILER=log`, inspect `storage/logs/laravel.log`.
- An already-done task does not send another message because the update compares the old and new status.
- Use `php artisan migrate --seed`, then sign in with `mark.garcia` / `password`.

## Required routes

- / - landing page
- /about - application and MVC explanation
- /customers - customer records retrieved with Customer::all(), with create and edit actions
- /users - user records retrieved with User::all(), with create, edit, and avatar actions

## InfinityFree upload

Upload the contents of this ZIP directly into the domain htdocs folder. The root index.php is a shared-hosting fallback that does not require Composer on the server. It preserves the same red, black, and white design and displays the seeded TFA6 customer and user records when the full Laravel runtime is unavailable.
